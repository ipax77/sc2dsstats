# Readme
SQL Server users: Run setup.pl before trying the Stored Procedure samples